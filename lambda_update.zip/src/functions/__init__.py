# Package initialization for functions module
