
"""
Twilio Configuration for AI Skills Assessment
Central configuration for Twilio voice calling and speech recognition.
"""

import os
from dataclasses import dataclass
from typing import Optional


@dataclass
class TwilioConfig:
    """Configuration for Twilio voice services."""
    account_sid: str
    auth_token: str
    api_key_sid: Optional[str] = None
    api_key_secret: Optional[str] = None
    voice_webhook_url: str = ""
    from_phone_number: str = "+14722368895"  # Gravy Work Twilio number: (472) 236-8895
    speech_timeout: str = "4"  # Default 4 seconds for thoughtful responses
    speech_model: str = "phone_call"
    profanity_filter: bool = False


# Default configurations for different environments
# NOTE: This file is LEGACY and not used by the current system.
# The active system uses environment variables directly in webhook_simple.py and assessment_processor_simple.py
# Actual Twilio config is managed in project.config.ts
DEFAULT_CONFIGS = {
    "development": TwilioConfig(
        account_sid="PLACEHOLDER_ACCOUNT_SID",  # Set via TWILIO_ACCOUNT_SID env var
        auth_token="PLACEHOLDER_AUTH_TOKEN",    # Set via TWILIO_AUTH_TOKEN env var
        from_phone_number="+14722368895",       # Your Twilio number: (472) 236-8895
        speech_timeout="4",
    ),
    
    "production": TwilioConfig(
        account_sid="PLACEHOLDER_ACCOUNT_SID",  # Set via TWILIO_ACCOUNT_SID env var
        auth_token="PLACEHOLDER_AUTH_TOKEN",    # Set via TWILIO_AUTH_TOKEN env var
        api_key_sid="PLACEHOLDER_API_KEY_SID",  # Set via TWILIO_API_KEY_SID env var (if needed)
        api_key_secret="PLACEHOLDER_API_SECRET", # Set via TWILIO_API_KEY_SECRET env var (if needed)
        from_phone_number="+14722368895",       # Your Twilio number: (472) 236-8895
        speech_timeout="4",
    ),
}


def get_twilio_config(environment: str = "development") -> TwilioConfig:
    """
    Get Twilio configuration with environment variable overrides.
    
    Args:
        environment: "development" or "production"
        
    Returns:
        TwilioConfig with resolved values
        
    Environment Variable Overrides:
        TWILIO_ACCOUNT_SID: Override account SID
        TWILIO_AUTH_TOKEN: Override auth token (required)
        TWILIO_API_KEY_SID: Override API key SID
        TWILIO_API_KEY_SECRET: Override API key secret
        TWILIO_WEBHOOK_URL: Override webhook URL
        TWILIO_FROM_NUMBER: Override from phone number
        TWILIO_SPEECH_TIMEOUT: Override speech timeout
    """
    if environment not in DEFAULT_CONFIGS:
        raise ValueError(f"Unknown Twilio environment: {environment}. Available: {list(DEFAULT_CONFIGS.keys())}")
    
    base_config = DEFAULT_CONFIGS[environment]
    
    return TwilioConfig(
        account_sid=os.environ.get("TWILIO_ACCOUNT_SID", base_config.account_sid),
        auth_token=os.environ.get("TWILIO_AUTH_TOKEN", base_config.auth_token),
        api_key_sid=os.environ.get("TWILIO_API_KEY_SID", base_config.api_key_sid),
        api_key_secret=os.environ.get("TWILIO_API_KEY_SECRET", base_config.api_key_secret),
        voice_webhook_url=os.environ.get("TWILIO_WEBHOOK_URL", ""),
        from_phone_number=os.environ.get("TWILIO_FROM_NUMBER", base_config.from_phone_number),
        speech_timeout=os.environ.get("TWILIO_SPEECH_TIMEOUT", base_config.speech_timeout),
        speech_model=os.environ.get("TWILIO_SPEECH_MODEL", base_config.speech_model),
        profanity_filter=os.environ.get("TWILIO_PROFANITY_FILTER", "false").lower() == "true",
    )


def get_development_config() -> TwilioConfig:
    """Get development Twilio configuration (test credentials)."""
    return get_twilio_config("development")


def get_production_config() -> TwilioConfig:
    """Get production Twilio configuration (live credentials with API key).""" 
    return get_twilio_config("production")